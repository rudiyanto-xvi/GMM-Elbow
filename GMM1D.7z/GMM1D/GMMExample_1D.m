

% $Author: ChrisMcCormick $    $Date: 2014/05/19 22:00:00 $    $Revision: 1.3 $
%%======================================================
%% STEP 1a: Generate data from two 1D distributions.
clear;
clc;

%Distribusi Gaussian 1
mu1 = 10;      % Mean (rata - rata)
sigma1 = 1;    % Sigma (kovarians)
m1 = 100;      % Number of points (jumlah data)

%Distribusi Gaussian 2
mu2 = 20;
sigma2 = 3;
m2 = 200;

%Distribusi Gaussian 3
mu3 = 30;
sigma3 = 2;
m3 = 300;

% Generate the data.
%X1 = (randn(m1, 1) * sigma1) + mu1;
%X2 = (randn(m2, 1) * sigma2) + mu2;
%X3 = (randn(m3, 1) * sigma3) + mu3;

X1 = csvread("DATA\X1.csv");
X2 = csvread("DATA\X2.csv");
X3 = csvread("DATA\X3.csv");

%writematrix(X1,'DATA\X1.csv');
%writematrix(X2,'DATA\X2.csv');
%writematrix(X3,'DATA\X3.csv');

X = [X1; X2; X3];

writematrix(X,'DATA\X.csv')

%%=====================================================
%% STEP 1b: Plot the data points and their pdfs.

x = 0:0.1:50;
y1 = gaussian1D(x, mu1, sigma1);
y2 = gaussian1D(x, mu2, sigma2);
y3 = gaussian1D(x, mu3, sigma3);

hold on;
plot(x, y1, 'b-');

hold on;
plot(x, y2, 'r-');

hold on;
plot(x, y3, 'g-')

plot(X1, zeros(size(X1)), 'bx', 'markersize', 10);
plot(X2, zeros(size(X2)), 'rx', 'markersize', 10);
plot(X3, zeros(size(X3)), 'gx', 'markersize', 10);
hold off;

set(gcf,'color','white') % White background for the figure.

%%====================================================
%% STEP 2: Choose initial values for the parameters.

% Set 'm' to the number of data points.
m = size(X, 1);

% Set 'k' to the number of clusters to find.
k = 2;
%k = 3;
%k = 4;

% Randomly select k data points to serve as the means.
indeces = randperm(m);
mu = zeros(1, k);
for (i = 1 : k)
    mu(i) = X(indeces(i));
end

% Use the overal variance of the dataset as the initial variance for each cluster.
sigma = ones(1, k) * sqrt(var(X));

% Assign equal prior probabilities to each cluster.
phi = ones(1, k) * (1 / k);

%%===================================================
%% STEP 3: Run Expectation Maximization

% Matrix to hold the probability that each data point belongs to each cluster.
% One row per data point, one column per cluster.
W = zeros(m, k);

% Loop until convergence.
for (iter = 1:1000)
    
    fprintf('  EM Iteration %d\n', iter);

    %%===============================================
    %% STEP 3a: Expectation
    %
    % Calculate the probability for each data point for each distribution.
    
    % Matrix to hold the pdf value for each every data point for every cluster.
    % One row per data point, one column per cluster.
    pdf = zeros(m, k);
    
    % For each cluster...
    for (j = 1 : k)
        
        % Evaluate the Gaussian for all data points for cluster 'j'.
        pdf(:, j) = gaussian1D(X, mu(j), sigma(j));
    end
    
    % Multiply each pdf value by the prior probability for each cluster.
    %    pdf  [m  x  k]
    %    phi  [1  x  k]   
    %  pdf_w  [m  x  k]
    pdf_w = bsxfun(@times, pdf, phi);
    
    % Divide the weighted probabilities by the sum of weighted probabilities for each cluster.
    %   sum(pdf_w, 2) -- sum over the clusters.
    W = bsxfun(@rdivide, pdf_w, sum(pdf_w, 2));
    
    %%===============================================
    %% STEP 3b: Maximization
    %%
    %% Calculate the probability for each data point for each distribution.

    % Store the previous means so we can check for convergence.
    prevMu = mu;    
    
    % For each of the clusters...
    for (j = 1 : k)
    
        % Calculate the prior probability for cluster 'j'.
        phi(j) = mean(W(:, j));
        
        % Calculate the new mean for cluster 'j' by taking the weighted
        % average of *all* data points.
        mu(j) = weightedAverage(W(:, j), X);
    
        % Calculate the variance for cluster 'j' by taking the weighted
        % average of the squared differences from the mean for all data
        % points.
        variance = weightedAverage(W(:, j), (X - mu(j)).^2);
        
        % Calculate sigma by taking the square root of the variance.
        sigma(j) = sqrt(variance);
    end
    
    % Check for convergence.
    % Comparing floating point values for equality is generally a bad idea, but
    % it seems to be working fine.
    if (mu == prevMu)
        break
    end

% End of Expectation Maximization loop.    
end

%%=====================================================
%% STEP 4: Plot the data points and their estimated pdfs.

x = [0:0.1:50];
y1 = gaussian1D(x, mu(1), sigma(1));
y2 = gaussian1D(x, mu(2), sigma(2));
%y3 = gaussian1D(x, mu(3), sigma(3));
%y4 = gaussian1D(x, mu(4), sigma(4));

writematrix(y1,'K2\RUN-5\GAUSSIAN\y1.csv');
writematrix(y2,'K2\RUN-5\GAUSSIAN\y2.csv');
%writematrix(y3,'K2\RUN-5\GAUSSIAN\y3.csv');
%writematrix(y4,'K2\RUN-5\GAUSSIAN\y4.csv');

% Plot over the existing figure, using black lines for the estimated pdfs.
plot(x, y1, 'k-');
hold on;
plot(x, y2, 'y-');
hold on;
%plot(x, y3, 'm-');
%hold on;
%plot(x, y4, 'c-');
%hold on;

img = gca;
exportgraphics(img,'K2\RUN-5\GMM1D-RUN-5.jpg') % Save a JPEG


%%SAVE BAGIAN GMM.=========================================================

%Varians
varians = "K2\RUN-5\Varians 1D-K2-RUN-5.csv";
writematrix(sigma, varians);

%Means
means = "K2\RUN-5\Means 1D-K2-RUN-5.csv";
writematrix(mu, means);

%Weight
weight = "K2\RUN-5\Weight 1D-K2-RUN-5.csv";
%writematrix(pdf_w, weight);
writematrix(phi, weight);

%Elbow
gmm = fitgmdist(X, k); %call function gmm
idx_of_result = cluster(gmm, X); %call function cluster | mengklaster nilai
knee = knee_pt(X, idx_of_result); %nilai optimal elbow

knee_elbow = "K2\RUN-5\KNEE-ELBOW-RESULT-RUN-5-K4.txt";
writematrix(knee, knee_elbow);

elbow = "K2\RUN-5\Elbow 1D-K2-RUN-5.csv";
writematrix(idx_of_result, elbow);

%%=====================================================
