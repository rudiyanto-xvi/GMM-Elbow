rng(0); % Set random seed for reproducibility
X = [randn(100, 2); randn(100, 2) + 5]; % Generate data points

% Fit GMM models with different number of components
n_components = 1:10;
models = cell(length(n_components), 1);
for i = 1:length(n_components)
    models{i} = fitgmdist(X, n_components(i));
end

% Calculate log-likelihood scores for each model
scores = zeros(length(n_components), 1);
for i = 1:length(n_components)
    scores(i) = sum(log(pdf(models{i}, X)));
end

% Plot the log-likelihood scores against the number of components
plot(n_components, scores, '-o');
xlabel('Number of components');
ylabel('Log-likelihood score');

% Find the elbow point using the second derivative of the scores
d1 = gradient(scores);
d2 = gradient(d1);
[~, elbow] = max(d2);

% Plot the elbow point
hold on;
plot(n_components(elbow), scores(elbow), 'ro');
hold off;

disp(['Elbow point: ', num2str(n_components(elbow))]);