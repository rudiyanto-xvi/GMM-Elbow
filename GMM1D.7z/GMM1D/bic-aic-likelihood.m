% Generate sample data
rng(1); % Set random seed for reproducibility
%data = [randn(1000,1); 5+randn(1000,1)]; % Two clusters with different means
F = readmatrix("data1D.txt")
%disp(X)
X1 = F(1:100)
length(X1)
X2 = F(101:300)
X3 = F(301:500)
X = [X1; X2; X3];
kl = 10 
% Fit GMMs with different numbers of components
maxComponents = kl; % Maximum number of components to try
BIC = zeros(maxComponents,1); % Initialize Bayesian Information Criterion (BIC) vector
AIC = zeros(maxComponents,1); % Initialize Akaike Information Criterion (AIC) vector
LL = zeros(maxComponents,1); % Initialize Log-Likelihood (LL) vector
gmms = cell(maxComponents,1); % Initialize cell array of GMMs
options = statset('MaxIter',1000); % Set maximum number of iterations for GMM fitting
for k = 1:maxComponents
    gmms{k} = fitgmdist(X,k,'Options',options); % Fit GMM with k components
    BIC(k) = gmms{k}.BIC; % Compute BIC
    AIC(k) = gmms{k}.AIC; % Compute AIC
    %LL(k) = sum(log(pdf(gmms{k},data))); % Compute LL
end

% Plot BIC, AIC, and LL as a function of the number of components
figure;
subplot(3,1,1); plot(1:maxComponents,BIC,'-o'); title('BIC');
subplot(3,1,2); plot(1:maxComponents,AIC,'-o'); title('AIC');
subplot(3,1,3); plot(1:maxComponents,LL,'-o'); title('Log-Likelihood');

% Compute elbow point using BIC, AIC, and LL
[~,bicElbow] = knee_pt(BIC,1:maxComponents); % knee_pt is a function for finding the knee point of a curve
[~,aicElbow] = knee_pt(AIC,1:maxComponents);
[~,llElbow] = knee_pt(LL,1:maxComponents);
disp(['BIC elbow: ',num2str(bicElbow)]);
disp(['AIC elbow: ',num2str(aicElbow)]);
disp(['LL elbow: ',num2str(llElbow)]);