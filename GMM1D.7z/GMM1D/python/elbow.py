# Import the necessary libraries:
import numpy as np
import matplotlib.pyplot as plt
from sklearn.mixture import GaussianMixture

# Generate a random dataset:
X = np.random.randn(1000, 3)

# Calculate the WCSS for different values of k (number of clusters):
wcss = []
for k in range(1, 11):
    gmm = GaussianMixture(n_components=k)
    gmm.fit(X)
    wcss.append(gmm.score(X))

# Plot the WCSS against the number of clusters:
plt.plot(range(1, 11), wcss)
plt.title('Elbow Method for Gaussian Mixture Model')
plt.xlabel('Number of Clusters')
plt.ylabel('WCSS')
plt.show()

# Identify the elbow point:
# Zooming in
plt.plot(range(1, 11), wcss)
plt.title('Elbow Method for Gaussian Mixture Model')
plt.xlabel('Number of Clusters')
plt.ylabel('WCSS')
plt.xticks(np.arange(1,11))
plt.xlim(2, 6)
plt.ylim(-4500,-2000)
plt.show()
