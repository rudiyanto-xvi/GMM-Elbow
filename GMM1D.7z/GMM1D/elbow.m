% Example usage
clear;
clc;

rng(1); % For reproducibility
X1 = csvread("DATA\X1.csv");
X2 = csvread("DATA\X2.csv");
X3 = csvread("DATA\X3.csv");

X = [X1; X2; X3]
elbow_gmm_1d(X, 10);