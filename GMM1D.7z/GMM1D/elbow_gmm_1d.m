function elbow_gmm_1d(X, max_components)
    n_components = 1:max_components;
    BIC = zeros(1, max_components);
    AIC = zeros(1, max_components);
    for n = n_components
        gm = fitgmdist(X, n);
        BIC(n) = gm.BIC;
        AIC(n) = gm.AIC;
    end
    plot(n_components, BIC, '-o', n_components, AIC, '-x')
    xlabel('Number of Components')
    ylabel('Information Criterion')
    legend('BIC', 'AIC', 'Location', 'northwest')
    title('GMM Elbow Plot')
end
