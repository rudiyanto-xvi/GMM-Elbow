rng(0); % Set random seed for reproducibility
%X = [randn(100, 2); randn(100, 2) + 5]; % Generate data points
%F = readmatrix("data1D.txt")
F = csvread("DATA\X.csv");
%disp(X)
X1 = F(1:100)
%length(X1)
X2 = F(101:200)
X3 = F(201:300)
X = [X1; X2; X3];
% Define range of number of clusters to try
k_range = 1:10;

% Initialize vector to store log-likelihood values
log_likelihoods = zeros(length(k_range),1);

% Fit GMM with different number of clusters and compute log-likelihoods
for k = k_range
    gm = fitgmdist(X,k,'RegularizationValue',0.1,'Options',statset('MaxIter',1000));
    log_likelihoods(k) = sum(log(pdf(gm,X)));
end

% Plot log-likelihoods versus number of clusters
figure
plot(k_range,log_likelihoods,'o-')
xlabel('Number of clusters')
ylabel('Log-likelihood')
title('Elbow method for GMM clustering with 3 Gaussian distributions')

% Find elbow point
differences = diff(log_likelihoods);
[difference_max,idx_max] = max(differences);
elbow_point = k_range(idx_max+1);

% Plot elbow point
hold on
elbow_plot = plot(elbow_point,log_likelihoods(elbow_point),'ro','MarkerSize',10,'LineWidth',2)
legend('Log-likelihood','Elbow point')

img = gca;
exportgraphics(img,'ELBOW\elbow-1d.jpg') % Save a JPEG
%writematrix(elbow_plot,'ELBOW\elbow-1d.csv');